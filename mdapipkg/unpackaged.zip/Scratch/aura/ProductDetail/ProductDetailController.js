({
    MovetoProductDetails : function(component, event, helper) {
        component.set("v.isProductDetailpage", true);
    }
})