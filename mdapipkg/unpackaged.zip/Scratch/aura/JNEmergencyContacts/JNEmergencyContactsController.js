({
  doInit: function(component, event, helper) {   
    helper.getAccounts(component);
  },
});